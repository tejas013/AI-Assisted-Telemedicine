import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Import routes
import authRoutes from './routes/auth.js';
import profileRoutes from './routes/profiles.js';
import appointmentRoutes from './routes/appointments.js';
import doctorRoutes from './routes/doctors.js';
import ngoRoutes from './routes/ngo.js';

// Import middleware
import { authenticate, authorize } from './middleware/auth.js';

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/shahyak')
  .then(() => {
    console.log('Connected to MongoDB');
    // After connection, check for doctors missing coordinates
    checkDoctorCoordinates();
  })
  .catch(err => console.error('MongoDB connection error:', err));

// Import models
import { User, Doctor, Client } from './models/User.js';
import Session from './models/Session.js';
import Appointment from './models/Appointment.js';
import NGO from './models/NGO.js';

// Check and fix doctors without coordinates
async function checkDoctorCoordinates() {
  try {
    // Find all doctors without coordinates
    const doctorsWithoutCoordinates = await Doctor.find({ 
      $or: [
        { coordinates: { $exists: false } },
        { coordinates: null }
      ] 
    });
    
    if (doctorsWithoutCoordinates.length > 0) {
      console.log(`Found ${doctorsWithoutCoordinates.length} doctors without coordinates. Adding default coordinates...`);
      
      // Default coordinates for New Delhi (for doctors without coordinates)
      const DEFAULT_COORDINATES = {
        latitude: 28.6139,  // New Delhi coordinates
        longitude: 77.2090
      };
      
      for (const doctor of doctorsWithoutCoordinates) {
        // Add small random offset to prevent all doctors from having the same coordinates
        const randomLat = (Math.random() - 0.5) * 0.05;  // +/- 0.025 degrees (~2.7 km)
        const randomLng = (Math.random() - 0.5) * 0.05;  // +/- 0.025 degrees
        
        // Set coordinates
        doctor.coordinates = {
          latitude: DEFAULT_COORDINATES.latitude + randomLat,
          longitude: DEFAULT_COORDINATES.longitude + randomLng
        };
        
        await doctor.save();
        console.log(`Updated doctor: ${doctor.name} (${doctor._id})`);
      }
      
      console.log('All doctors now have coordinates!');
    } else {
      console.log('All doctors already have coordinates.');
    }
  } catch (error) {
    console.error('Error checking doctor coordinates:', error);
  }
}

// Use routes
app.use('/api/auth', authRoutes);
app.use('/api/profiles', profileRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/doctors', doctorRoutes);
app.use('/api/ngo', ngoRoutes);

// Health check route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Protected route example
app.get('/api/protected', authenticate, (req, res) => {
  res.json({ message: 'This is a protected route', user: req.user });
});

// Doctor-only route example
app.get('/api/doctor-only', authenticate, authorize('Doctor'), (req, res) => {
  res.json({ message: 'This is a doctor-only route', user: req.user });
});

// Client-only route example
app.get('/api/client-only', authenticate, authorize('Client'), (req, res) => {
  res.json({ message: 'This is a client-only route', user: req.user });
});

// Global error handler - must be placed after all routes
app.use((err, req, res, next) => {
  console.error('Global error handler caught:', err);
  
  // Ensure all errors return JSON responses
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    stack: process.env.NODE_ENV === 'production' ? undefined : err.stack
  });
});

// Catch-all for unhandled routes (404) - must be placed after all valid routes
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Serve static assets in production
if (process.env.NODE_ENV === 'production') {
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename);
  
  // Set static folder
  app.use(express.static(join(__dirname, '../dist')));
  
  app.get('*', (req, res) => {
    res.sendFile(join(__dirname, '../dist/index.html'));
  });
}

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});