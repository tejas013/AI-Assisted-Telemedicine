import mongoose from 'mongoose';

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Event title is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Event description is required'],
    trim: true
  },
  date: {
    type: Date,
    required: [true, 'Event date is required']
  },
  time: {
    start: {
      type: String,
      required: [true, 'Start time is required']
    },
    end: {
      type: String,
      required: [true, 'End time is required']
    }
  },
  location: {
    address: {
      type: String,
      required: [true, 'Event address is required'],
      trim: true
    },
    city: {
      type: String,
      required: [true, 'City is required'],
      trim: true
    },
    state: {
      type: String,
      required: [true, 'State is required'],
      trim: true
    },
    coordinates: {
      latitude: { 
        type: Number,
        required: [true, 'Latitude is required']
      },
      longitude: { 
        type: Number,
        required: [true, 'Longitude is required']
      }
    }
  },
  eventType: {
    type: String,
    required: [true, 'Event type is required'],
    enum: ['Medical Camp', 'Awareness Drive', 'Blood Donation', 'Vaccine Drive', 'Free Checkup', 'Other'],
    default: 'Medical Camp'
  },
  services: [{
    type: String,
    trim: true
  }],
  organizer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'NGO',
    required: [true, 'Organizer is required']
  },
  contactInfo: {
    name: {
      type: String,
      required: [true, 'Contact person name is required'],
      trim: true
    },
    phone: {
      type: String,
      required: [true, 'Contact phone is required'],
      match: [/^\+?[1-9]\d{1,14}$/, 'Please enter a valid phone number']
    },
    email: {
      type: String,
      required: [true, 'Contact email is required'],
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Please enter a valid email']
    }
  },
  imageUrl: {
    type: String,
    default: '/defaults/event-default.jpg'
  },
  status: {
    type: String,
    enum: ['upcoming', 'ongoing', 'completed', 'cancelled'],
    default: 'upcoming'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Helper method to check if event is active (upcoming or ongoing)
eventSchema.methods.isActive = function() {
  return this.status === 'upcoming' || this.status === 'ongoing';
};

// Middleware to update status based on date
eventSchema.pre('save', function(next) {
  const now = new Date();
  const eventDate = new Date(this.date);
  
  // Set event to 'upcoming' if it's in the future
  if (eventDate > now) {
    this.status = 'upcoming';
  } 
  // Set event to 'ongoing' if it's today
  else if (
    eventDate.getDate() === now.getDate() && 
    eventDate.getMonth() === now.getMonth() && 
    eventDate.getFullYear() === now.getFullYear()
  ) {
    this.status = 'ongoing';
  } 
  // Set event to 'completed' if it's in the past
  else {
    this.status = 'completed';
  }
  
  next();
});

const Event = mongoose.model('Event', eventSchema);

export default Event; 